const firebaseConfig = {
    apiKey: "AIzaSyCkeoPhFgY5t8Z6YX86sh1ddZr-_eSOI2s",
    authDomain: "netflix-clone-b0729.firebaseapp.com",
    projectId: "netflix-clone-b0729",
    storageBucket: "netflix-clone-b0729.appspot.com",
    messagingSenderId: "378933190151",
    appId: "1:378933190151:web:c47d5985d386a4640d94a2"
  };